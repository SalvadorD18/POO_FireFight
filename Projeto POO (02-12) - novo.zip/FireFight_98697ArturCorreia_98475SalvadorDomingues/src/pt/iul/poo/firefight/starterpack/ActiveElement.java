package pt.iul.poo.firefight.starterpack;

public interface ActiveElement {
	
	public void activateElement();

}
