package pt.iul.poo.firefight.starterpack;

public interface Burnable {
	
	public void burn();
	
}