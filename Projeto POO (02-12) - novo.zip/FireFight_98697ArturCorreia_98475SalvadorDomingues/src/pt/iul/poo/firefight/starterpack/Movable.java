package pt.iul.poo.firefight.starterpack;

public interface Movable {

	public void move(int key);
}
