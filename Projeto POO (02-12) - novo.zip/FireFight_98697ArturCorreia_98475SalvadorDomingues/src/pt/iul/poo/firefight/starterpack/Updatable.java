package pt.iul.poo.firefight.starterpack;

public interface Updatable {
	
	public void updateElement();
	
}
